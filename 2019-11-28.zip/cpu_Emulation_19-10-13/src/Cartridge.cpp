/*
 * Cartridge.cpp
 *
 *  Created on: 17.10.2019
 *      Author: N1
 *      What does this class,
 *      it's the rom
 */
// this is the cartridge -- it is the module which has the game data stored !
// nevertheless game data need to be stored in this module first !
// so there is a method which can read in from a data file into an 8 Bit array :D
// later isntances of the module can be send its data to the chip8 Interpreter / dissembler
// --------------------------
#include "Cartridge.h"
#include <fstream>
#include <iostream>
Cartridge::Cartridge() {
	for (int i = 0; i < 1024; i++) {
		opCodeCartridge[i] = 0;
	}
}
Cartridge::Cartridge(string fileName) { // creates a new cartridge with content: 0
	setFileName(fileName);
	for (int i = 0; i < 1024; i++) {
		opCodeCartridge[i] = 0;
	}
}

Cartridge::~Cartridge() {
}

void Cartridge::readInOpcodeFromFileInArray(string fileName) { // reads opcode from a file into the "opcode array"
	setFileName(fileName);
	streampos size; //  Groesse wird hier wohl gespeichert .... typ streampos ? size = gr��e char bytes ...
	char * memblock;
	cout << "Name of File: " << fileName << endl;
	//	filesize(fileName.c_str());
	ifstream file2(fileName.c_str(), ios::in | ios::binary | ios::ate); // inputstream
	if (file2.is_open()) {
		size = file2.tellg(); // TELL: tellg() and tellp() geben streampos zur�ck ( aktuelle get/put position) / size is the size of
		setOpcodeLength(size); // important! the byte size is given to an internal variable
		memblock = new char[size];
		file2.seekg(0, ios::beg); // SEEK: seekg() and seekp()  - Ver�ndern der Orte von get und put

		file2.read(memblock, size);// lese in memblock rein , von der groesse size( anzahl der bytes)
		int save;
		for (int i = 0; i < size; i++) { //size = groesse  e
			int a = memblock[i];
			cout << "" << memblock[i] << " :";
			cout << " \t0x" << hex << (a & 0x0FF) << "\t=  0b";

			// here just the binary output happens - just for the closer loop of the variable
			for (int k = 0; k < 8; k++) {
				save = (0x80 >> k) & memblock[i]; // schiebe von links nach rechts
				if (save)
					cout << "1";
				else
					cout << "0";
				if (k == 3)
					cout << " ";
			}
			cout << "\n";
		}
		// ###here the memblock variable is transfered to the Cartridge !!
		for (int i = 0; i < size; i++) { // here the real reading in happens !
			// very important to mask again !!
			this->opCodeCartridge[i] = (0x0000FF & memblock[i]); // just 8 Bit into the opcodeCartridge !
		}

	}
}

char * Cartridge::getOpcode() {
	return this->opCodeCartridge;
}
string Cartridge::getFileName() const {
	return fileName;
}

void Cartridge::setFileName(string fileName) {
	this->fileName = fileName;
}

void Cartridge::printOpcode() { // prints the opcode of the ARRAY!!!!
	cout << "\nOpcodeArrays of Cartridge:";
	cout << "(Cartridge-ROM name: " << getFileName() << " )" << endl;
	size_t n = sizeof(this->opCodeCartridge) / sizeof(this->opCodeCartridge[0]);

	// loop through the elements of the array
	for (size_t i = 0; i < n; i++) {
		// prints it out byte after byte !
		printf("0x%.2X ", opCodeCartridge[i] & 0x00FF); // AUsgabe !!! AUfj eden fall auf MASKE achten !1
		//		std::cout << "0x" << std::hex << this->opCodeCartridge[i];

	}
	cout << "\nEND of OpcodeArray" << endl;
}

void Cartridge::setOpcodeLength(int l) {
	this->opCodeLength = l;
}
int Cartridge::getOpcodeLength() {
	return this->opCodeLength;
}

// this function was desgned to read in data from a test array with test opcode.. but now we are already able to read in data from a real file !
void Cartridge::readInOpcodeFromArray(unsigned short int *opCodeArray) {
	int arraySize = sizeof(opCodeArray) / sizeof(*opCodeArray) / 2;// get length of array
	cout << "array size:" << arraySize << endl;
	for (int i = 0; i < arraySize; i++) {
		// read the opcodes and save them int
		this->opCodeCartridge[i] = opCodeArray[i];
	}
}
