/*
 * C8Klasse.cpp
 *
 *  Created on: 17.10.2019
 *      Author: Nikki
 */

#include "C8Klasse.h"
#include <math.h>
#include <iostream>
using namespace std;
C8Klasse::C8Klasse() {
	// TODO Auto-generated constructor stub

}

C8Klasse::~C8Klasse() {
	// TODO Auto-generated destructor stub
}
void C8Klasse::initMemory() {
	// wichtig auch die Sprites f�r die Schrift in den Speicher zu laden:(0x000 to 0x1FF)
	cout << "\nSpeicher Init" << endl;
	// Speicher Anlegen 0xFFF = 4095
	setCounter(0);
	setPC(0);

	for (int i = 0; i < 0xFFF; i++) {
		memory[i] = 0;

	}
}

unsigned short int C8Klasse::getCounter() const {
	return counter;
}

unsigned short int C8Klasse::getPC() const {
	return PC;
}

void C8Klasse::setCounter(unsigned short int counter) {
	this->counter = counter;
}

void C8Klasse::setOpCode(Cartridge cartridge) {//### copies the opcode of the cartridge into the memory array! todo check if its correct !
	cout << "#cartridge name:" << cartridge.fileName << endl;
	char * opcode = cartridge.getOpcode();

	for (int i = 0; i < 1024; i++) {//begins at the address 0x200 , transferes the opcode of the cartridge into the memory
		memory[0x200 + i] = opcode[i];
		//cout << "##" << memory[0x200+i] << endl;
	}
	cout << "#####" << endl;
}
void C8Klasse::setPC(unsigned short int PC) {
	this->PC = PC;
}
void C8Klasse::printMemoryFrom(int i) { // this function has the same name but adds a paramet - print Memory beginning with index i
	cout
			<< "\nBegin: Print of the C8 Processor internal memory ! From Adress 0x"
			<< hex << i << " to 0xFFF" << endl;
	size_t n = sizeof(this->memory) / sizeof(this->memory[0]);// calculates the total amount of elements in memory array

	// loop through the elements of the array begins with index i !
	for (size_t h = i; h < n; h++) {
		printf("0x%.2X ", memory[h] & 0x00FF); // AUsgabe !!! AUfj eden fall auf MASKE achten !1
		//		std::cout << hex << this->memory[i] << ' ';
	}
	cout << "\nEND of print Memory:" << endl;
}
void C8Klasse::printMemory() {
	cout << "\nC8 Memory content:" << endl;
	size_t n = sizeof(this->memory) / sizeof(this->memory[0]); // calculate array size of memory[]

	// loop through the elements of the array
	for (size_t i = 0; i < n; i++) {
		printf("0x%.2X ", this->memory[i] & 0x00FF); // AUsgabe !!! AUfj eden fall auf MASKE achten !1
		//		std::cout << hex << this->memory[i] << ' ';
	}
	cout << "\nEND C8 Memory content" << endl;
}
unsigned short int C8Klasse::getMemoryAtPC() {
	return this->memory[getPC()];
}
void C8Klasse::incrementPC(int inc) {
	setPC(getPC() + inc);
}
void C8Klasse::incrementStackPointer(int inc) {
	setPC(getPC() + inc);
}

void C8Klasse::writeToStack(unsigned short int adr) {
	stack[getStackPointer()] = adr;
}
char C8Klasse::getStackPointer() {
	return sp;
}
void C8Klasse::setStackPointer(unsigned short int SP) {
	this->sp = SP;
}
void C8Klasse::softDissemblerScanMemory() {
	unsigned short int opCode = 0;
	for (int i = 0x200; i < 0x300; i++) {
		opCode = 0;
		opCode = ((unsigned short int) ((memory[i] & (0xff))) << 8);
		opCode = opCode | (((unsigned short int) (memory[i + 1] & (0xff))));// getting opc2 and ORing it to the first part !
		if(i%2 == 0)
		{softDissembler(opCode, i);
		cout << "\n";
		}else{}
	}
}
void C8Klasse::softDissembler(unsigned short int opcode, int i) {
	cout << "[softDissembler] ";
	cout << "addr: " << i;
	cout << " op: 0x" << hex << opcode << ",";
	if ((opcode & 0xF000) == 0x1000) {//## Jump Befehl ! //1nnn - JP addr Jump to location nnn.The interpreter sets the program counter to nnn.
		//setPC(opcode & 0x0FFF);// setze den PC auf die letzten drei HExa stellen..weil memory ja 12 Bit Adresse hat!....
		cout << "1NNN: JP to NNN";
	} else {

	}
	//		2nnn - CALL addr Call subroutine at nnn. The interpreter increments the stack pointer, then puts the current PC on the top of the stack. The PC is then set to nnn.
	if ((opcode & 0xF000) == 0x2000) {//## call subroutine befehl
		cout << "2NNN: Call SUB at nnn";
		// inkrementiere den Stackpointer
		//incrementStackPointer(1);
		// kopiere den PC auf den Stack
		//setStackPointer(getPC());
		// PC  zu nnn
		//setPC(opcode & 0x0FFF);
	} else {

	}
	if ((opcode & 0xF000) == 0x3000) {//## 3xkk  --Skip next instruction if Vx = kk.
		// x isolieren:
		cout << "3XNN: if (Vx=kk)PC+2";
		// x in integer 0 bis 15 umwandeln f�r den Zugriff auf Vx Register
		int x = transformHexTo0to15(opcode & 0x0F00, 3); // maskiere opcode und wandle dann diese stelle in 0 bis 15 um ein Vx register zu w�hlen
		if (V[x] == (opcode & (0x00FF)))// vergleiche die beiden letzten Stellen des opcodes mit dem Inhalt des Vx Regsiters
		{
			//incrementPC(2); // wenn inhalt von vx gleich opcode kk ,, dann PC+2 !
		} else {

		}

	} else {
	}
	if ((opcode & 0xF000) == 0x4000) {//## call subroutine befehl 			4xkk - SNE Vx, byte			Skip next instruction if Vx != kk.			The interpreter compares register Vx to kk, and if they are not equal, increments the program counter by 2.
		// x isolieren:
		// x in integer 0 bis 15 umwandeln f�r den Zugriff auf Vx Register
		cout << "4XNN:if (Vx != kk)PC+2 ";
		int x = transformHexTo0to15(opcode & 0x0F00, 3); // maskiere opcode und wandle dann diese stelle in 0 bis 15 um ein Vx register zu w�hlen
		if (V[x] != (opcode & (0x00FF)))// vergleiche die beiden letzten Stellen des opcodes mit dem Inhalt des Vx Regsiters
		{
			//incrementPC(2); // wenn inhalt von vx UNgleich opcode kk ,, dann PC+2 !
		} else {

		}

	} else {
	}
	if ((opcode & 0xF000) == 0x5000) {//## call subroutine befehl 5xy0 - SE Vx, Vy Skip next instruction if Vx = Vy. The interpreter compares register Vx to register Vy, and if they are equal, increments the program counter by 2.
		cout << "5xy0: if (Vx == Vy)PC+2 ";
		int x = transformHexTo0to15(opcode & 0x0F00, 3);
		int y = transformHexTo0to15(opcode & 0x00F0, 2);
		if (V[x] == V[y]) {// wenn Vx == Vy dann
			//incrementPC(2);
		} else {
		}
	} else {
	}
	if ((opcode & 0xF000) == 0x6000) {//## call subroutine befehl6xkk - LD Vx, byte		Set Vx = kk.		The interpreter puts the value kk into register Vx.
		cout << "6XNN: set Vx = kk";
		// kk muss in Register Vx
		int x = transformHexTo0to15(opcode & 0x0F00, 3); // berechne welche array nummer es ist !
		V[x] = opcode & 0x00FF; // f�ge kk in Vx rein !
	} else {

	}
	if ((opcode & 0xF000) == 0x7000) {//## call subroutine befehl 7xkk - ADD Vx, byte		Set Vx = Vx + kk.	Adds the value kk to the value of register Vx, then stores the result in Vx.
		cout << "7XNN: set Vx =Vx + kk";
		// setzte Vx zu Vx +kk !
		// berechne index x aus dem opcode:
		int x = transformHexTo0to15(opcode & 0x0F00, 3);
		// extrahiere die Zahl kk aus dem opcode !
		int kk = opcode & 0x00FF;// sind ja die letzten beiden Stellen
		//f�hre die Berchnung am Register Vx durch !
		V[x] = V[x] + kk; // aso inhalt von Vx + kk
	} else {
	}
	// ########################### 0x8 Command !
	if ((opcode & 0xF000) == 0x8000) {//## call subroutine befehl
		cout << "0x8 (Assign): differenciate between 0...E ";
		// hier muss man nochmals unterscheiden was hinten steht !
		// betrachte die letzte stelle- rechts:
		int logicType = opcode & 0x000F;
		// hier kann man erst einmal x und y aus dem opcode extrahieren... damit man das nicht f�r jeden case neu machen muss!
		int x = transformHexTo0to15(opcode & 0x0F00, 3);
		int y = transformHexTo0to15(opcode & 0x00F0, 2);
		int sum1 = V[x]; // weil wenn man chars addieren w�rde und mehr als 255 rauskommt, dann evtl wieder von 0 angefangen wird... da kann man nichts verlgeich etc...
		int sum2 = V[y];
		switch (logicType) {//8xy0 - LD Vx, Vy			Set Vx = Vy.			Stores the value of register Vy in register Vx.
		case 0: // speichere Vy in Vx
			V[x] = V[y];
			break;
		case 0x0001://Set Vx = Vx OR Vy.
			V[x] = V[x] | V[y];
			break;
		case 0x0002:// 8xy2 - AND Vx, Vy
			V[x] = V[x] & V[y];
			break;
		case 0x0003://8xy3 - XOR Vx, Vy
			V[x] = V[x] ^ V[y];
			break;
		case 0x0004://ADD Vx, Vy -- achtung wenn gr��er als 255 dann Carry Flag setzen : VF =1 !
			V[x] = V[x] + V[y];

			if ((sum1 + sum2) > 255)
				//	V[15] = 1; // VF = 1....
				break;
		case 0x0005://8xy5 - SUB Vx, Vy
			//If Vx > Vy, then VF is set to 1, otherwise 0
			if (V[x] > V[y])
				V[15] = 1;
			else
				V[15] = 0;
			//Then Vy is subtracted from Vx, and the results stored in Vx
			//V[x] = V[x] - V[y];
			break;
		case 0x0006://	8xy6 - SHR Vx {, Vy}
			//If the least-significant bit of Vx is 1, then VF is set to 1, otherwise 0.
			if ((V[x] & 0x0001) == 0x0001)// wenn das Bit ganz rechts 1 ist
				V[15] = 1;
			else
				V[15] = 0;
			//Then Vx is divided by 2. okeeey
			//V[x] = V[x] / 2;
			break;
		case 0x0007://8xy7 - SUBN Vx, Vy

			//Set Vx = Vy - Vx,
			//If Vy > Vx
			if (V[y] > V[x])
				V[15] = 1;
			else
				V[15] = 0;
			//Then Vx is subtracted from Vy, and the results stored in Vx.
			//	V[x] = V[x] - V[y];
			break;
		case 0x000E://8xyE - SHL Vx {, Vy}
			//If the most-significant bit of Vx is 1
			if ((V[x] & 0x8000) == 0x8000) // bt ganz links auf 1 ?...then VF is set to 1, otherwise to 0.
				V[15] = 1;
			else
				V[15] = 0;
			//Then Vx is multiplied by 2.
			//V[x] = V[x] * 2;
			break;
			//# ende von 0x8000 behandlung
		default:
			break;
		}// ende switch..
	} else {
	} // wenn ein anderer fall als 0x8000}
	//#####---------------------------------------------------------  0x9000
	// ## einfach uwischendurch x und y extrahieren xD
	int x = transformHexTo0to15(opcode & 0x0F00, 3);
	int y = transformHexTo0to15(opcode & 0x00F0, 2);
	if ((opcode & 0xF000) == 0x9000) {//##The values of Vx and Vy are compared, and if they are not equal, the program counter is increased by 2.
		cout << "VxyComp";
		if (V[x] != V[y])//Skip next instruction if Vx != Vy.
		{
			//incrementPC(2);
		}//d if they are not equal, the program counter is increased by 2
		else {
		}
		// nichts
	} else {

	}
	//###################################################################### ~~~~~~~~~  ABCDE Commands !!!
	if ((opcode & 0xF000) == 0xA000) {//##Annn  The value of register I is set to nnn.
		//setI(opcode & 0x0FFF);
		cout << "ANNN: I = NNN";
	} else {

	}
	if ((opcode & 0xF000) == 0xB000) {//##		//The program counter is set to nnn plus the value of V0.
		cout << "BNNN: pc = NNN + V0";
		//setPC((opcode & 0x0FFF) + V[0]);
	} else {

	}
	if ((opcode & 0xF000) == 0xC000) {//## Cxkk - RND Vx, byte---Set Vx = random byte AND kk.
		cout << "CXNN: set Vx = rand Byte And kk";
		//int x = transformHexTo0to15(opcode & 0x0F00);
		//char number = rand() % 256;
		//V[x] = number & (opcode & 0x00FF);
	} else {

	}
	if ((opcode & 0xF000) == 0xD000) {//## GRAFICOPERTION!!! Dxyn - DRW Vx, Vy, nibble
		// Display n-byte sprite starting at memory location I at (Vx, Vy), set VF = collision.
		// interpreter reads n bytes from memory
		// 1.) find out n:
		cout << "DXYN: Grafics";
		int n = transformHexTo0to15(opcode & 0x000F, 1); // get the lowest 4 Bit as decimal value...
		int x = transformHexTo0to15(opcode & 0x0F00, 3); // get the lowest 4 Bit as decimal value...
		int y = transformHexTo0to15(opcode & 0x00F0, 2); // get the lowest 4 Bit as decimal value...
		// start at the address stored in Register I !
		for (int i = 0; i < n; i++) {

			//				spriteDisplay(memory[I + i * 2],x,y);//These bytes are then displayed as sprites on screen at coordinates (Vx, Vy)
		}
	} else {

	}
	//############# toDo : hier noch mal unterscheiden Ex9E ExA1
	if ((opcode & 0xF000) == 0xE000) {//TASTE Skip next instruction if key with the value of Vx is pressed.
		cout << "Skip next inst. if key pressed";
	} else {

	}
	//############# F die letzten beiden stellen m�ssen unterschieden werden!
	x = transformHexTo0to15(opcode & 0x0F00, 3);
	y = transformHexTo0to15(opcode & 0x00F0, 2);
	if ((opcode & 0xF000) == 0xF000) {//## call subroutine befehl
		cout << "Fnn";
		int lastTwoDigits = opcode & 0x00FF;
		switch (lastTwoDigits) {
		case 0x0007://			The value of DT is placed into Vx.
			//V[x] = getDT();
			break;

		case 0x000A: // KEY todo
			//Wait for a key press, store the value of the key in Vx.
			break;
		case 0x0015://DT is set equal to the value of Vx.
			//setDT(V[x]);
			break;
		case 0x0018://ST is set equal to the value of Vx.
			//setST(V[x]);

			break;
		case 0x001E://The values of I and Vx are added, and the results are stored in I. Set I = I + Vx.
			//setI(V[x] + getI());
			break;
		case 0x0029://Set I = location of sprite for digit Vx. todo

			break;
		case 0x0033: //todo Store BCD representation of Vx in memory locations I, I+1, and I+2.

			break;
		case 0x0055://Fx55 -Store registers V0 through Vx in memory starting at location I.
			//The interpreter copies the values of registers V0 through Vx into memory, starting at the address in I.
			//Speichern Sie die Register V0 bis Vx ab Position I.
			for (int i = 0; i <= x; i++) { // von 0 bis x
				//memory[getI() + i] = V[i]; // kopiere von memory Position I an, alle V bis Vx....

			}
			break;
		case 0x0065://Read registers V0 through Vx from memory starting at location I.
			for (int i = 0; i <= x; i++) { // von 0 bis x
				V[i] = memory[getI() + i]; // kopiere von, alle V bis Vx... memory Position I an.

			}
			break;
		default:
			break;
		}
	} else {

	}

	//Wcout << "PC:" << PC << " mem[2]:" << memory[2] << endl; // prunsigned short ints !!!Hello World!!!
	if (counter <= 0) {
		// wenn z�hler schon bei 0 angekommen ist oder sogar weniger hat als 0 dann f�hre etwas aus , sonst nicht...
	} else {
	}
	cout << "                                              \t  [/SoftDissembler]";

}
void C8Klasse::dissembler(unsigned short int opcode) { // atention the opcode is saved in a memory with only width of 8 bit !!!
	cout << "[Dissembler] ";
	cout << "addr: " << getPC();
	cout << " op: 0x" << hex << opcode << ",";
	if ((opcode & 0xF000) == 0x1000) {//## Jump Befehl ! //1nnn - JP addr Jump to location nnn.The interpreter sets the program counter to nnn.
		setPC(opcode & 0x0FFF);// setze den PC auf die letzten drei HExa stellen..weil memory ja 12 Bit Adresse hat!....
		cout << "1NNN: JP to NNN";
	} else {

	}
	//		2nnn - CALL addr Call subroutine at nnn. The interpreter increments the stack pointer, then puts the current PC on the top of the stack. The PC is then set to nnn.
	if ((opcode & 0xF000) == 0x2000) {//## call subroutine befehl
		cout << "2NNN: Call SUB at nnn";
		// inkrementiere den Stackpointer
		incrementStackPointer(1);
		// kopiere den PC auf den Stack
		setStackPointer(getPC());
		// PC  zu nnn
		setPC(opcode & 0x0FFF);
	} else {

	}
	if ((opcode & 0xF000) == 0x3000) {//## 3xkk  --Skip next instruction if Vx = kk.
		// x isolieren:
		cout << "3XNN: if (Vx=kk)PC+2";
		// x in integer 0 bis 15 umwandeln f�r den Zugriff auf Vx Register
		int x = transformHexTo0to15(opcode & 0x0F00, 3); // maskiere opcode und wandle dann diese stelle in 0 bis 15 um ein Vx register zu w�hlen
		if (V[x] == (opcode & (0x00FF)))// vergleiche die beiden letzten Stellen des opcodes mit dem Inhalt des Vx Regsiters
		{
			incrementPC(2); // wenn inhalt von vx gleich opcode kk ,, dann PC+2 !
		} else {

		}

	} else {
	}
	if ((opcode & 0xF000) == 0x4000) {//## call subroutine befehl 			4xkk - SNE Vx, byte			Skip next instruction if Vx != kk.			The interpreter compares register Vx to kk, and if they are not equal, increments the program counter by 2.
		// x isolieren:
		// x in integer 0 bis 15 umwandeln f�r den Zugriff auf Vx Register
		cout << "4XNN:if (Vx != kk)PC+2 ";
		int x = transformHexTo0to15(opcode & 0x0F00, 3); // maskiere opcode und wandle dann diese stelle in 0 bis 15 um ein Vx register zu w�hlen
		if (V[x] != (opcode & (0x00FF)))// vergleiche die beiden letzten Stellen des opcodes mit dem Inhalt des Vx Regsiters
		{
			incrementPC(2); // wenn inhalt von vx UNgleich opcode kk ,, dann PC+2 !
		} else {

		}

	} else {
	}
	if ((opcode & 0xF000) == 0x5000) {//## call subroutine befehl 5xy0 - SE Vx, Vy Skip next instruction if Vx = Vy. The interpreter compares register Vx to register Vy, and if they are equal, increments the program counter by 2.
		cout << "5xy0: if (Vx == Vy)PC+2 ";
		int x = transformHexTo0to15(opcode & 0x0F00, 3);
		int y = transformHexTo0to15(opcode & 0x00F0, 2);
		if (V[x] == V[y]) {// wenn Vx == Vy dann
			incrementPC(2);
		} else {
		}
	} else {
	}
	if ((opcode & 0xF000) == 0x6000) {//## call subroutine befehl6xkk - LD Vx, byte		Set Vx = kk.		The interpreter puts the value kk into register Vx.
		cout << "6XNN: set Vx = kk";
		// kk muss in Register Vx
		int x = transformHexTo0to15(opcode & 0x0F00, 3); // berechne welche array nummer es ist !
		V[x] = opcode & 0x00FF; // f�ge kk in Vx rein !
	} else {

	}
	if ((opcode & 0xF000) == 0x7000) {//## call subroutine befehl 7xkk - ADD Vx, byte		Set Vx = Vx + kk.	Adds the value kk to the value of register Vx, then stores the result in Vx.
		cout << "7XNN: set Vx =Vx + kk";
		// setzte Vx zu Vx +kk !
		// berechne index x aus dem opcode:
		int x = transformHexTo0to15(opcode & 0x0F00, 3);
		// extrahiere die Zahl kk aus dem opcode !
		int kk = opcode & 0x00FF;// sind ja die letzten beiden Stellen
		//f�hre die Berchnung am Register Vx durch !
		V[x] = V[x] + kk; // aso inhalt von Vx + kk
	} else {
	}
	// ########################### 0x8 Command !
	if ((opcode & 0xF000) == 0x8000) {//## call subroutine befehl
		cout << "0x8 (Assign): differenciate between 0...E ";
		// hier muss man nochmals unterscheiden was hinten steht !
		// betrachte die letzte stelle- rechts:
		int logicType = opcode & 0x000F;
		// hier kann man erst einmal x und y aus dem opcode extrahieren... damit man das nicht f�r jeden case neu machen muss!
		int x = transformHexTo0to15(opcode & 0x0F00, 3);
		int y = transformHexTo0to15(opcode & 0x00F0, 2);
		int sum1 = V[x]; // weil wenn man chars addieren w�rde und mehr als 255 rauskommt, dann evtl wieder von 0 angefangen wird... da kann man nichts verlgeich etc...
		int sum2 = V[y];
		switch (logicType) {//8xy0 - LD Vx, Vy			Set Vx = Vy.			Stores the value of register Vy in register Vx.
		case 0: // speichere Vy in Vx
			V[x] = V[y];
			break;
		case 0x0001://Set Vx = Vx OR Vy.
			V[x] = V[x] | V[y];
			break;
		case 0x0002:// 8xy2 - AND Vx, Vy
			V[x] = V[x] & V[y];
			break;
		case 0x0003://8xy3 - XOR Vx, Vy
			V[x] = V[x] ^ V[y];
			break;
		case 0x0004://ADD Vx, Vy -- achtung wenn gr��er als 255 dann Carry Flag setzen : VF =1 !
			V[x] = V[x] + V[y];

			if ((sum1 + sum2) > 255)
				V[15] = 1; // VF = 1....
			break;
		case 0x0005://8xy5 - SUB Vx, Vy
			//If Vx > Vy, then VF is set to 1, otherwise 0
			if (V[x] > V[y])
				V[15] = 1;
			else
				V[15] = 0;
			//Then Vy is subtracted from Vx, and the results stored in Vx
			V[x] = V[x] - V[y];
			break;
		case 0x0006://	8xy6 - SHR Vx {, Vy}
			//If the least-significant bit of Vx is 1, then VF is set to 1, otherwise 0.
			if ((V[x] & 0x0001) == 0x0001)// wenn das Bit ganz rechts 1 ist
				V[15] = 1;
			else
				V[15] = 0;
			//Then Vx is divided by 2. okeeey
			V[x] = V[x] / 2;
			break;
		case 0x0007://8xy7 - SUBN Vx, Vy

			//Set Vx = Vy - Vx,
			//If Vy > Vx
			if (V[y] > V[x])
				V[15] = 1;
			else
				V[15] = 0;
			//Then Vx is subtracted from Vy, and the results stored in Vx.
			V[x] = V[x] - V[y];
			break;
		case 0x000E://8xyE - SHL Vx {, Vy}
			//If the most-significant bit of Vx is 1
			if ((V[x] & 0x8000) == 0x8000) // bt ganz links auf 1 ?...then VF is set to 1, otherwise to 0.
				V[15] = 1;
			else
				V[15] = 0;
			//Then Vx is multiplied by 2.
			V[x] = V[x] * 2;
			break;
			//# ende von 0x8000 behandlung
		default:
			break;
		}// ende switch..
	} else {
	} // wenn ein anderer fall als 0x8000}
	//#####---------------------------------------------------------  0x9000
	// ## einfach uwischendurch x und y extrahieren xD
	int x = transformHexTo0to15(opcode & 0x0F00, 3);
	int y = transformHexTo0to15(opcode & 0x00F0, 2);
	if ((opcode & 0xF000) == 0x9000) {//##The values of Vx and Vy are compared, and if they are not equal, the program counter is increased by 2.
		cout << "VxyComp";
		if (V[x] != V[y])//Skip next instruction if Vx != Vy.
		{
			incrementPC(2);
		}//d if they are not equal, the program counter is increased by 2
		else {
		}
		// nichts
	} else {

	}
	//###################################################################### ~~~~~~~~~  ABCDE Commands !!!
	if ((opcode & 0xF000) == 0xA000) {//##Annn  The value of register I is set to nnn.
		setI(opcode & 0x0FFF);
		cout << "ANNN: I = NNN";
	} else {

	}
	if ((opcode & 0xF000) == 0xB000) {//##		//The program counter is set to nnn plus the value of V0.
		cout << "BNNN: pc = NNN + V0";
		setPC((opcode & 0x0FFF) + V[0]);
	} else {

	}
	if ((opcode & 0xF000) == 0xC000) {//## Cxkk - RND Vx, byte---Set Vx = random byte AND kk.
		cout << "CXNN: set Vx = rand Byte And kk";
		//int x = transformHexTo0to15(opcode & 0x0F00);
		//char number = rand() % 256;
		//V[x] = number & (opcode & 0x00FF);
	} else {

	}
	if ((opcode & 0xF000) == 0xD000) {//## GRAFICOPERTION!!! Dxyn - DRW Vx, Vy, nibble
		// Display n-byte sprite starting at memory location I at (Vx, Vy), set VF = collision.
		// interpreter reads n bytes from memory
		// 1.) find out n:
		cout << "DXYN: Grafics";
		int n = transformHexTo0to15(opcode & 0x000F, 1); // get the lowest 4 Bit as decimal value...
		int x = transformHexTo0to15(opcode & 0x0F00, 3); // get the lowest 4 Bit as decimal value...
		int y = transformHexTo0to15(opcode & 0x00F0, 2); // get the lowest 4 Bit as decimal value...
		// start at the address stored in Register I !
		for (int i = 0; i < n; i++) {

			//				spriteDisplay(memory[I + i * 2],x,y);//These bytes are then displayed as sprites on screen at coordinates (Vx, Vy)
		}
	} else {

	}
	//############# toDo : hier noch mal unterscheiden Ex9E ExA1
	if ((opcode & 0xF000) == 0xE000) {//TASTE Skip next instruction if key with the value of Vx is pressed.
		cout << "Skip next inst. if key pressed";
	} else {

	}
	//############# F die letzten beiden stellen m�ssen unterschieden werden!
	x = transformHexTo0to15(opcode & 0x0F00, 3);
	y = transformHexTo0to15(opcode & 0x00F0, 2);
	if ((opcode & 0xF000) == 0xF000) {//## call subroutine befehl
		cout << "Fnn";
		int lastTwoDigits = opcode & 0x00FF;
		switch (lastTwoDigits) {
		case 0x0007://			The value of DT is placed into Vx.
			V[x] = getDT();
			break;

		case 0x000A: // KEY todo
			//Wait for a key press, store the value of the key in Vx.
			break;
		case 0x0015://DT is set equal to the value of Vx.
			setDT(V[x]);
			break;
		case 0x0018://ST is set equal to the value of Vx.
			setST(V[x]);

			break;
		case 0x001E://The values of I and Vx are added, and the results are stored in I. Set I = I + Vx.
			setI(V[x] + getI());
			break;
		case 0x0029://Set I = location of sprite for digit Vx. todo

			break;
		case 0x0033: //todo Store BCD representation of Vx in memory locations I, I+1, and I+2.

			break;
		case 0x0055://Fx55 -Store registers V0 through Vx in memory starting at location I.
			//The interpreter copies the values of registers V0 through Vx into memory, starting at the address in I.
			//Speichern Sie die Register V0 bis Vx ab Position I.
			for (int i = 0; i <= x; i++) { // von 0 bis x
				memory[getI() + i] = V[i]; // kopiere von memory Position I an, alle V bis Vx....

			}
			break;
		case 0x0065://Read registers V0 through Vx from memory starting at location I.
			for (int i = 0; i <= x; i++) { // von 0 bis x
				V[i] = memory[getI() + i]; // kopiere von, alle V bis Vx... memory Position I an.

			}
			break;
		default:
			break;
		}
	} else {

	}

	//Wcout << "PC:" << PC << " mem[2]:" << memory[2] << endl; // prunsigned short ints !!!Hello World!!!
	if (counter <= 0) {
		// wenn z�hler schon bei 0 angekommen ist oder sogar weniger hat als 0 dann f�hre etwas aus , sonst nicht...
	} else {
	}
	cout << "  [/Dissembler] ";
}

int C8Klasse::transformHexTo0to15(unsigned short int input, int hexaBlock) { // this function is for decoding the opcode !- somehow we have to translate hex number into decimal number, by just looking at the value e.g. 0x0006 at the positon 1 ist 6 !// berechne wie geteilt werden muss um ein sinnvolles ergebnis f�r diese stelle zu erhalten,ganz rechts w�re 1:
// 1 Hexa Block = 2
//2 Hexa Block = 4
// 3 Hexa Block = 8
// also nochmal pow ( 2,hexaBlock)..
// transformHexTo0to15(0x0600,3); // so 3 means the third from the right side !
// bsp: (0000 0110 0000 0000) / 2^3 =>6
// ist gut wenn man genau diese stelle umrechnen m�chte...
	return input / pow(2, pow(2, hexaBlock)); // 2^8 = 256 ... dann erh�lt man f�r diese stelle den dezimalwert... !
}

unsigned short int C8Klasse::getI() const {
	return I;
}

void C8Klasse::setI(unsigned short int I) {
	this->I = I;
}

unsigned short int C8Klasse::getDT() const {
	return DT;
}

void C8Klasse::setDT(unsigned short int DT) {
	this->DT = DT;
}

unsigned short int C8Klasse::getST() const {
	return ST;
}

void C8Klasse::setST(unsigned short int ST) {
	this->ST = ST;
}
