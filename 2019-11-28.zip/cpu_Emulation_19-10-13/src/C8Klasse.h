/*
 * C8Klasse.h
 *
 *  Created on: 17.10.2019
 *      Author: Nikki
 */

#ifndef C8KLASSE_H_
#define C8KLASSE_H_
#include "Cartridge.h"
class C8Klasse {
public:
	C8Klasse();
	virtual ~C8Klasse();
	void initMemory();
	unsigned short int getCounter() const;
	unsigned short int getPC() const;
	unsigned short int getOpCode(Cartridge cartridge);
	char getStackPointer();
	void dissembler(unsigned short int opcode); // executes the passed opc !
	void softDissembler(unsigned short int opcode, int i);// just dissambles the hex code and tells the opc code as string
	void softDissemblerScanMemory();// its just a method to dissamble the opcode in the memory it doesnt execute something !
	void setCounter(unsigned short int counter);
	void setOpCode(Cartridge cartridge); // puts the opcode of the cartridge into the memory array!
	void setPC(unsigned short int PC);
	void setStackPointer(unsigned short int SP);
	//	unsigned short int getMemory();
	void printMemory();
	void printMemoryFrom(int i); // print out from a specific index
	unsigned short int getMemoryAtPC();
	void incrementPC(int inc);
	void incrementStackPointer(int inc);
	void writeToStack(unsigned short int adr);
	int transformHexTo0to15(unsigned short int input, int hexaBlock);
	unsigned short int getI() const;
	void setI(unsigned short int I);
	unsigned short int getDT() const;
	void setDT(unsigned short int DT);
	unsigned short int getST() const;
	void setST(unsigned short int ST);

	char V[16];
	char memory[0xFFF]; // why is this 2 Byte ???? it should be only 1 Byte !!!!!!!!!!!!!!
private:
	unsigned short int DT;
	unsigned short int ST;
	unsigned short int I;
	unsigned short int counter;
	unsigned short int PC;
	unsigned short int opcode;
	unsigned short int stack[16];
	char sp;
};

#endif /* C8KLASSE_H_ */
/**
 *
 +---------------+= 0xFFF (4095) End of Chip-8 RAM
 |               |
 |               |
 |               |
 |               |
 |               |
 | 0x200 to 0xFFF|
 |     Chip-8    |
 | Program / Data|
 |     Space     |
 |               |
 |               |
 |               |
 +- - - - - - - -+= 0x600 (1536) Start of ETI 660 Chip-8 programs
 |               |
 |               |
 |               |
 +---------------+= 0x200 (512 Byte !!!!!!!!!!!!) Start of most Chip-8 programs
 | 0x000 to 0x1FF|
 | Reserved for  |
 |  unsigned short interpreter  |
 +---------------+= 0x000 (0) Start of Chip-8 RAM


 * */
