/*
 * Cartridge.h
 *
 *  Created on: 17.10.2019
 *      Author: N1
 *      This class is supposed to read the opcode from a file !
 *      it saves it into its own opcode arrays
 *      then in the other class the opcode is read into the memory array of the chip8 emulator !
 *	for testing issues it also would be possible to create a array with some opcode
 */

#ifndef CARTRIDGE_H_
#define CARTRIDGE_H_
#include "iostream"
using namespace std;
class Cartridge {
public:
	Cartridge();
	Cartridge(string fileName);
	void readInOpcodeFromFileInArray(string fileName); // get opcode from a file in the cartride Opcode array ! you can tipe in :D you can call this method in the constructor for example :D
	void readInOpcodeFromArray(unsigned short int *opCodeArray);
	unsigned short int testOpcode[2] = { 0x00EE, 0x00E0 }; // array size needs to be declared because of inclass declaration..
	int getOpcodeLength();// give back array length of opcode, gebe die l�nge des eingegebenen Opcodes zur�ck...
	void setOpcodeLength(int l); // set array length of opcode
	string getFileName() const;
	void setFileName(string fileName);
	string fileName;
	char * getOpcode(); // gebe den Opcode zur�ck
	unsigned short int entfernenopCodeCartridge[1024]; // this is an array for Opcode- its the opcode of the cartridge
	char opCodeCartridge[1024];
	int opCodeLength;

	virtual ~Cartridge();
	void printOpcode();
};

#endif /* CARTRIDGE_H_ */

/**
 *
 +---------------+= 0xFFF (4095) End of Chip-8 RAM
 |               |
 |               |
 |               |
 |               |
 |               |
 | 0x200 to 0xFFF|
 |     Chip-8    |
 | Program / Data|
 |     Space     |
 |               |
 |               |
 |               |
 +- - - - - - - -+= 0x600 (1536) Start of ETI 660 Chip-8 programs
 |               |
 |               |
 |               |
 +---------------+= 0x200 (512) Start of most Chip-8 programs
 | 0x000 to 0x1FF|
 | Reserved for  |
 |  unsigned short interpreter  |
 +---------------+= 0x000 (0) Start of Chip-8 RAM


 * */
