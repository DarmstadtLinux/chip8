//============================================================================
// Name        : cpu_Emulation_19-10-13.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
//https://fms.komkon.org/EMUL8/HOWTO.html

// todo: iam programming the dissambler which just checks my given in commands.. 1927 - 31.10.2019
#include <iostream>
#include <stdint.h>
#include "C8Klasse.h"
#include "Cartridge.h"
#include <stdio.h>
#include <GL/glut.h>
#include <intrin.h> // damit kann man zyklen auslesen...https://stackoverflow.com/questions/13772567/how-to-get-the-cpu-cycle-count-in-x86-64-from-c
using namespace std;
//  Windows
//#ifdef _WIN32

// what does this whole thing: it ist a Chip8 Interpreter
static const char rom_name[] = "maze.rom";
C8Klasse c8; // lege interpreter an
Cartridge testCartridge; // declare a Cartridge ( its the rom with the game data !!// lege Cartridge an
unsigned short int memory[1000]; // annahem
void initMemory() {
	memory[0] = 0;
	memory[1] = 1;
}
void display() {

}

void idle() {
	unsigned short int opCode = 0; // cache or storing opcode
	//## getting opc
	//## explanation for getting opc: opCOde is a unsigned short int ( 16 Bit )! the memory is just 8 Bit ! bit-maipulation necessairy: executableOpcode=(opcode1 <<8) | (opcode2)
	//will begin with ... normaly... (look in main...)0x200
	opCode = ((unsigned short int) ((c8.getMemoryAtPC() & (0xff))) << 8);// # get first part of opc! memory =  get opcode1
	c8.incrementPC(1); // increment PC - for getting next part of opc !
	opCode = opCode | (((unsigned short int) (c8.getMemoryAtPC() & (0xff))));// getting opc2 and ORing it to the first part !
	//## end getting opc
	c8.incrementPC(1); // increment PC -- for the next round
	c8.dissembler(opCode); // so if the opcode variable is fille with 2 Bytes please run the dissembler !

	//cout << "\ncurrent pc: 0x" << hex << c8.getPC();
	//		cout << ", the read out OpCode is:0x" << hex << opCode; // show opcode.
	//printf(" the read OpCode : 0x%04x", opCode);
	//if(c8.getPC()==0x300)
	cin.get();
	//cout<<"pc = "<<c8.getPC();
	// man muss bei den Befehlen unterscheiden:  befehle fangen mit einer fixen Zahl an und haben dann variablen!
	// man muss deswegen zuerst schauen welche zahl am Anfang steht oder , man muss nach einer Zahlenkombinatuon suchen
	//Befehle: http://devernay.free.fr/hacks/chip8/C8TECH10.HTM
	//Hex to ASCII converter : https://www.rapidtables.com/convert/number/hex-to-ascii.html
}
void glutInitRoutines() {
	glutInitWindowSize(64, 32);
	glutCreateWindow("Chip8 V5");
	glutDisplayFunc(display); // die obige Funktion display wird als Bildchirm behandler bekanntgemacht
	//glutSpecialFunc( process_Normal_Keys);
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, 32.0, 64.0, 0.0);
	glutIdleFunc(idle);
	glutMainLoop();
	//void glutIdleFunc(void (*func)(void)
}
void initC8WithCartridge() {

	// #Start Chip8
	c8.initMemory(); // initialisiere den Speicher zu 0
	// #Setup cartridge
	testCartridge.readInOpcodeFromFileInArray(rom_name); // reads opcode of a data-file (should be in workspace) into an intern array
	c8.setOpCode(testCartridge);// here the Opcode of the game is passed to the c8 CPU ( Cartridge ->internal memory )!
	c8.setPC(0x200); // starte mit dem PC auf Adresse 0x200 !
}

int main(int argc, char **argv) {
	initC8WithCartridge(); // execute important stuff
	cout << "begin\n" << endl;
	testCartridge.printOpcode();
	// # Cartridgecode to Chip8 Memory
	c8.printMemoryFrom(0x200); // here the c8 internal memory is printed out, should be same form 0x200 to 0xfff with cartridge , since the game has been read in !
	c8.softDissemblerScanMemory();
	cin.get();
	glutInit(&argc, argv);
	glutInitRoutines(); // initialisation for opengGL window
	return 0;
}
/*
 *
 All instructions are 2 bytes long and are stored most-significant-byte first.
 In memory, the first byte of each instruction should be located at an even addresses.
 3.1 - Standard Chip-8 Instructions
 00E0 - CLS
 00EE - RET
 0nnn - SYS addr
 1nnn - JP addr
 2nnn - CALL addr
 3xkk - SE Vx, byte
 4xkk - SNE Vx, byte
 5xy0 - SE Vx, Vy
 6xkk - LD Vx, byte
 7xkk - ADD Vx, byte
 8xy0 - LD Vx, Vy
 8xy1 - OR Vx, Vy
 8xy2 - AND Vx, Vy
 8xy3 - XOR Vx, Vy
 8xy4 - ADD Vx, Vy
 8xy5 - SUB Vx, Vy
 8xy6 - SHR Vx {, Vy}
 8xy7 - SUBN Vx, Vy
 8xyE - SHL Vx {, Vy}
 9xy0 - SNE Vx, Vy
 Annn - LD I, addr
 Bnnn - JP V0, addr
 Cxkk - RND Vx, byte
 Dxyn - DRW Vx, Vy, nibble
 Ex9E - SKP Vx
 ExA1 - SKNP Vx
 Fx07 - LD Vx, DT
 Fx0A - LD Vx, K
 Fx15 - LD DT, Vx
 Fx18 - LD ST, Vx
 Fx1E - ADD I, Vx
 Fx29 - LD F, Vx
 Fx33 - LD B, Vx
 Fx55 - LD [I], Vx
 Fx65 - LD Vx, [I]
 3.2 - Super Chip-48 Instructions
 00Cn - SCD nibble
 00FB - SCR
 00FC - SCL
 00FD - EXIT
 00FE - LOW
 00FF - HIGH
 Dxy0 - DRW Vx, Vy, 0
 Fx30 - LD HF, Vx
 Fx75 - LD R, Vx
 Fx85 - LD Vx, R
 * */
